GENESIS Core — Contenedor v4 (autocontenido)
- Contiene v2_fix con su hash y Carta v3.
- Usar el hash de v2_fix para verificación de integridad.
