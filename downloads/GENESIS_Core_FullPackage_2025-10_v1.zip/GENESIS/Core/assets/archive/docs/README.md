# Gemini 4.0 – Centro de Mando
